<?php

// Start the session to access session variables
session_start();

// Check if the user is logged in by verifying the existence of 'user_id' in the session
if (isset($_SESSION['user_id'])) 
{
    // Redirect user based on their role
    switch ($_SESSION['role']) 
    {
        case 'admin':
            header("Location: pages/admin.php");
            exit();
        case 'customer':
            header("Location: pages/customer.php");
            exit();
        case 'kitchen':
            header("Location: pages/kitchen.php");
            exit();
        case 'delivery':
            header("Location: pages/delivery.php");
            exit();

        default:
            // If the role is unrecognized, destroy the session and redirect to login
            session_destroy();
            header("Location: auth/Login.php");
            exit();
            break;
    }
} 
else 
{
    // If user is not logged in, redirect to the login page
    header("Location: auth/Login.php");
    exit();
}
?>

