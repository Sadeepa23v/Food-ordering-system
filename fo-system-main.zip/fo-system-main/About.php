<?php include 'includes/header.php'; ?>

<!-- About Section -->
<div class="about" id="About">
    <h1 class="about-title">About<span>Us</span></h1>
    
    <div class="about_main_content">
        
            <div class="about_image">
            <img src="image/Food-Plate.png" alt="Food Plate">
            </div>
            
            <div class="about_main_text">
            <h3>Why Choose us?</h3>
            <p>                
                We’re more than just a food delivery service — we’re your trusted partner in getting fresh, delicious meals whenever you need them.
                With a commitment to quality, reliability, and customer satisfaction, we make food ordering fast, simple, and worry-free.
                Our experienced team ensures timely deliveries, hygienic preparation, and a wide variety of options to suit every taste.
                From convenience to care, we put you first — every order, every time.
            </p>        
            </div>                       
    </div>

    <div class="about_services">
    <h2>Our<span> Services</span></h2>
    <br>
    <div class="about_services_list">
        <div class="about_services_item"><i class="fa-solid fa-clock"></i> - 24/7 Service</div>
        <div class="about_services_item"><i class="fa-solid fa-truck"></i> - Fast Delivery</div>
        <div class="about_services_item"><i class="fa-solid fa-utensils"></i> - Wide Food Variety</div>
        <div class="about_services_item"><i class="fa-solid fa-credit-card"></i> - Multiple Payment Options</div>
        <div class="about_services_item"><i class="fa-solid fa-location-dot"></i> - Real-Time Order Tracking</div>
        <div class="about_services_item"><i class="fa-solid fa-gift"></i> - Exclusive Offers & Discounts</div>
        <div class="about_services_item"><i class="fa-solid fa-phone-volume"></i> - Customer Support</div>
    </div>
    </div>
</div>

    <div class="team">
        <h2>Our<span>Team</span></h2>
        <br>
        
        <div class="team_box">
            <div class="profile">
                <img src="image/chef1.png">

                <div class="info">
                    <h4 class="name">Chef Anura Perera</h4>
                <p class="bio">Master of traditional Sri Lankan rice & curry with 20+ years of culinary experience.</p>
                    <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>

            </div>

            <div class="profile">
                <img src="image/chef2.png">

                <div class="info">
                    <h4 class="name">Chef Nadeesha Silva</h4>
                    <p class="bio">Renowned for her innovative coconut-based desserts and fusion dishes.</p>
                    <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>

            </div>

            <div class="profile">
                <img src="image/chef3.jpg">

                <div class="info">
                <h4 class="name">Chef Kamal Jayasinghe</h4>
                <p class="bio">Expert in seafood and coastal cuisine, especially Jaffna-style crab curry.</p>
                <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>

            </div>

            <div class="profile">
                <img src="image/chef4.jpg">

                <div class="info">
                    <h4 class="name">Chef Ruwan Gunasekara</h4>
                    <p class="bio">Pastry chef with international experience specializing in Sri Lankan sweets.</p>
                    <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>
            </div>

            <div class="profile">
                <img src="image/chef5.png">

                <div class="info">
                    <h4 class="name">Chef Dilani Fernando</h4>
                    <p class="bio">Known for healthy Sri Lankan vegetarian dishes and ayurvedic food concepts.</p>
                    <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>
            </div>

        </div>

    </div>

<?php include 'includes/footer.php'; ?>               


                

             

                