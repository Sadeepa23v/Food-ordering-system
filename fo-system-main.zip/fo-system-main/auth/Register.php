<?php
session_start();
include '../configure.php'; 

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $role = $_POST['role'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Secure password
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    // Check for existing email
    $checkQuery = "SELECT * FROM users WHERE Email = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['error'] = "Email already registered.";
    } else {
        // Insert new user
        $insertQuery = "INSERT INTO users (Role, Name, Email, Password, Phone_Number, Address) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("ssssss", $role, $name, $email, $password, $phone, $address);

        if ($stmt->execute()) {
            $_SESSION['success'] = "Registration successful!";
            header("Location: Login.php");
        } else {
            $_SESSION['error'] = "Registration failed. Please try again.";
            header("Location: Register.php");
        }
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="/FO-System/style.css">
</head>

<body class="register-body">
    <div class="register-card">
        <?php
        if (isset($_SESSION['error'])) {
            echo '<div class="error-message">'.$_SESSION['error'].'</div>';
            unset($_SESSION['error']);
        }
        if (isset($_SESSION['success'])) {
            echo '<div class="success-message">'.$_SESSION['success'].'</div>';
            unset($_SESSION['success']);
        }
        ?>
        <form name="RegisterForm" method="post" onsubmit="return validateFields()">
            <div class="form-group">
                <label for="role">Role</label>
                <select name="role" id="role" required>
                    <option value="" disabled selected>Select Role</option>
                    <option value="Customer">Customer</option>
                    <option value="Kitchen">Kitchen</option>
                    <option value="Delivery">Delivery</option>
                </select>
            </div>

            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" name="name" id="name" required placeholder="Enter your full name">
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" required placeholder="Enter your email">
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" required placeholder="Enter your password">
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" name="phone" id="phone" required placeholder="Enter your phone number">
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" name="address" id="address" required placeholder="Enter your address">
            </div>

            <input type="submit" name="register" value="REGISTER">
        </form>

        <a class="login-link" href="Login.php">Already have an account? Login</a>
    </div>

    <script>
        function validateFields() {
            const password = document.getElementById('password').value;
            if (password.length < 6) {
                alert("Password must be at least 6 characters.");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
