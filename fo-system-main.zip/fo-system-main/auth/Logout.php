<?php
session_start();
session_destroy();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Ordering System</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>


<div class="logout-message" style="max-width:400px;margin:60px auto;padding:32px 24px;background:#c4e0e8;border-radius:10px;box-shadow:0 2px 12px rgba(0,0,0,0.08);text-align:center;">
    <h2>You have been logged out.</h2>
    <p>Redirecting to <a href="Login.php">Login</a> page...</p>
</div>
<script>
    setTimeout(function() {
        window.location.href = 'Login.php';
    }, 1800);
</script>