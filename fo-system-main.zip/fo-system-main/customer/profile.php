<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Ordering System - Customer Dashboard</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<?php
include '../includes/session_check.php';
checkRole('customer');
include '../configure.php';
include '../includes/customer_header.php';
?>

<?php

// Check if user_id is set in session
if (!isset($_SESSION['user_id'])) {
    echo "<div class='profile-container'><div class='profile-message'>Session expired. Please log in again.</div></div>";
    include '../includes/footer.php';
    exit;
}

$user_id = $_SESSION['user_id'];

$query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    echo "<div class='profile-container'><div class='profile-message'>Database error: " . htmlspecialchars($conn->error) . "</div></div>";
    include '../includes/footer.php';
    exit;
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    echo "<div class='profile-container'><div class='profile-message'>Database error: " . htmlspecialchars($stmt->error) . "</div></div>";
    include '../includes/footer.php';
    exit;
}

echo "<div class='profile-container'>";
echo "<h2>Your Profile</h2>";

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "<p><strong>User ID:</strong> " . htmlspecialchars($row['User_ID']) . "</p>";
    echo "<p><strong>Role:</strong> " . htmlspecialchars($row['Role']) . "</p>";
    echo "<p><strong>Name:</strong> " . htmlspecialchars($row['Name']) . "</p>";
    echo "<p><strong>Email:</strong> " . htmlspecialchars($row['Email']) . "</p>";
    echo "<p><strong>Phone Number:</strong> " . htmlspecialchars($row['Phone_Number']) . "</p>";
    echo "<p><strong>Address:</strong> " . htmlspecialchars($row['Address']) . "</p>";
} 
else {
    echo "<div class='profile-message'>User details not found.</div>";
}
echo "</div>";

?>

<?php include '../includes/footer.php'; ?>