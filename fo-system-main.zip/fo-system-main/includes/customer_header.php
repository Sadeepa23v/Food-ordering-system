<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>

<header class="header">
    <div style="display: flex; align-items: center; justify-content: space-between; max-width: 1100px; margin: 0 auto; padding: 12px 24px;">
        <div>
            <a href="../pages/customer.php">
                <img src="../image/logo.png" alt="Logo" class="header-logo" style="height:48px;">
            </a>
        </div>
        <nav>
            <a href="../pages/customer.php" 
               style="margin-right:20px; color:#000; font-weight:bold; text-decoration:none; <?= $current_page == 'customer.php' ? 'border-bottom: 2px solid #3498db;' : '' ?>">
               <i class="fa fa-home"></i> Home
            </a>
            <a href="../customer/browse_menu.php" 
               style="margin-right:20px; color:#000; font-weight:bold; text-decoration:none; <?= $current_page == 'browse_menu.php' ? 'border-bottom: 2px solid #3498db;' : '' ?>">
               <i class="fa fa-bars"></i> Menu
            </a>
            <a href="../customer/order_history.php" 
               style="margin-right:20px; color:#000; font-weight:bold; text-decoration:none; <?= $current_page == 'order_history.php' ? 'border-bottom: 2px solid #3498db;' : '' ?>">
               <i class="fa fa-utensils"></i> My Orders
            </a>
            <a href="../customer/profile.php" 
               style="margin-right:20px; color:#000; font-weight:bold; text-decoration:none; <?= $current_page == 'profile.php' ? 'border-bottom: 2px solid #3498db;' : '' ?>">
               <i class="fa fa-user"></i> My Profile
            </a>
            <a href="../auth/logout.php" 
               style="color:#e74c3c; font-weight:bold; text-decoration:none;">
               <i class="fa fa-sign-out-alt"></i> Logout
            </a>
        </nav>
    </div>
</header>
