<header class="header">
    <div style="display: flex; align-items: center; justify-content: space-between; max-width: 1100px; margin: 0 auto; padding: 12px 24px;">
        <div>
            <a href="../pages/admin.php">
                <img src="../image/logo.png" alt="Logo" class="header-logo" style="height:48px;">
            </a>
        </div>
        <nav>
            <a href="../pages/admin.php" style="margin-right:20px; color:#black; font-weight:bold; text-decoration:none;"><i class="fa fa-home"></i> Home</a>
            <a href="../admin/manage_users.php" style="margin-right:20px; color:#black; font-weight:bold; text-decoration:none;"><i class="fa fa-users"></i> Users</a>
            <a href="../admin/manage_orders.php" style="margin-right:20px; color:#black; font-weight:bold; text-decoration:none;"><i class="fa fa-list"></i> Orders</a>
            <a href="../admin/manage_food_items.php" style="margin-right:20px; color:#black; font-weight:bold; text-decoration:none;"><i class="fa fa-utensils"></i> Food Items</a>
            <a href="../auth/logout.php" style="color:#e74c3c; font-weight:bold; text-decoration:none;"><i class="fa fa-sign-out-alt"></i> Logout</a>
        </nav>
    </div>
</header>