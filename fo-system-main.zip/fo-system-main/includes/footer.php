
</main>
<footer role="contentinfo">
    <div class="footer_main">

        <div class="footer_tag">
            <h2>Location</h2>
            <a href="https://www.google.com/maps?q=Galle+Road,+Colombo+03+(Kollupitiya),+Sri+Lanka" target="_blank">
            <p><i class="fa-solid fa-location-dot"></i><p></a>
            <p>Galle Road,</p>
            <p>Colombo 03 (Kollupitiya),</p>
            <p>Sri Lanka</p>
        </div>

        <div class="footer_tag">
            <h2>Quick Link</h2>
            <p><a href="/FO-System/Home.php">Home</a></p>
            <p><a href="/FO-System/About.php">About</a></p>
            <p><a href="/FO-System/Menu.php">Menu</a></p>
            <p><a href="/FO-System/Reviews.php">Review</a></p>
        </div>

        <div class="footer_tag">
            <h2>Contact</h2>
            <p><a href="tel:+94720711504">+94 720711504</a></p>
            <p><a href="tel:+94112293000">+94 112293000</a></p>
            <p><a href="mailto:johndoe123@gmail.com">johndoe123@gmail.com</a></p>
            <p><a href="mailto:info@food.lk">info@food.lk</a></p>
        </div>

        <div class="footer_tag">
            <h2>Follows</h2>
            <a href="https://www.facebook.com" title="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="https://www.twitter.com" title="Twitter"><i class="fa-brands fa-twitter"></i></a>
            <a href="https://www.instagram.com" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://www.linkedin.com" title="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
        </div>

    </div>

    <p class="end">Designed by <span><i class="fa-solid fa-face-grin"></i> FD Master Code</span></p>
</footer>

<script src="/FO-System/script.js"></script>
</body>
</html>