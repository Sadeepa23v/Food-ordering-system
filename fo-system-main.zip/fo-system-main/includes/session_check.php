<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function checkRole($role) 
{
    if (!isset($_SESSION['user_id']) || strtolower($_SESSION['role']) !== strtolower($role))
    {
        header("Location: ../auth/Login.php");
        exit();
    }
}