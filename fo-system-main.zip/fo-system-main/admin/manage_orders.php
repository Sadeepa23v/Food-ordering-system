<?php
include '../includes/session_check.php';
checkRole('admin');
include '../configure.php';
include '../includes/admin_header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Ordering System - Admin Dashboard</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
</html>

<div class="admin-orders-container">
    <h2>Manage Orders</h2>
    <?php
    $query = "SELECT o.ID, u.Name AS Customer_Name, o.Total, o.Status, o.Order_Time
              FROM orders o
              JOIN users u ON o.User_ID = u.User_ID
              ORDER BY o.Order_Time DESC";

    $result = mysqli_query($conn, $query);

    if (!$result) {
        echo "<p style='color:red;'>Error fetching orders: " . htmlspecialchars(mysqli_error($conn)) . "</p>";
        include '../includes/footer.php';
        exit;
    }

    echo "<table class='admin-orders-table'>";
    echo "<thead>
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Total (₹)</th>
                <th>Status</th>
                <th>Order Time</th>
                <th>Actions</th>
            </tr>
          </thead>
          <tbody>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['ID'] . "</td>";
        echo "<td>" . htmlspecialchars($row['Customer_Name']) . "</td>";
        echo "<td>" . number_format($row['Total'], 2) . "</td>";
        echo "<td>" . htmlspecialchars($row['Status']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Order_Time']) . "</td>";
        echo "<td><a class='action-link' href='edit_order.php?id=" . $row['ID'] . "'>Edit Status</a></td>";
        echo "</tr>";
    }
    echo "</tbody></table>";
    ?>
</div>

<?php include '../includes/footer.php'; ?>