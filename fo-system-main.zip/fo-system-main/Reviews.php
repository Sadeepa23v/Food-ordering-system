<?php include 'includes/header.php'; ?>

    <!--Review-->
    <section class="review" id="Review">
        <h1>Customer<span>Review</span></h1>

        <div class="review_box">

            <div class="review_card">

                <div class="review_profile">
                    <img src="image/review_1.png">
                </div>

                <div class="review_text">
                    <h2 class="name">Sarah Fernando</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        "Absolutely love this service! The food is always fresh and arrives right on time. 
                        The platform is easy to use and has so many great options. Highly recommended!"
                    </p>
                </div>
            </div>

            <div class="review_card">
                <div class="review_profile">
                    <img src="image/review_2.png">
                </div>

                <div class="review_text">
                    <h2 class="name">Lahiru S.</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        "Good vibes. Nice UI, fast checkout, and food doesn’t disappoint. Add more dessert options tho plz 😭"
                    </p>
                </div>
            </div>

            <div class="review_card">
                <div class="review_profile">
                    <img src="image/review_3.png">
                </div>

                <div class="review_text">
                    <h2 class="name">Dinuli Wijesinghe</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        "This has become my go-to food ordering platform. Super reliable, and I love how I can track my order in real time. The kitchen staff does a fantastic job!"
                    </p>
                </div>
            </div>

            <div class="review_card">
                <div class="review_profile">
                    <img src="image/review_4.png">
                </div>

                <div class="review_text">
                    <h2 class="name">Kavindu Perera</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        "Great variety and fast delivery. One star off because my drink was missing once, but customer support handled it quickly. Will definitely keep ordering!"
                    </p>
                </div>
            </div>

            <div class="review_card">
                <div class="review_profile">
                    <img src="image/review_5.png">
                </div>

                <div class="review_text">
                    <h2 class="name">Janith M.</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        "Yo this app is a lifesaver! I was starving late at night and got hot kottu in like 25 mins. Bless up 🙌🔥"
                    </p>
                </div>
            </div>

            <div class="review_card">
                <div class="review_profile">
                    <img src="image/review_6.png">
                </div>

                <div class="review_text">
                    <h2 class="name">Nadeesha Silva</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        "Perfect for busy days! I’ve been ordering lunch from here for weeks and it never disappoints. The portions are generous and the taste is amazing."
                    </p>
                </div>
            </div>

            <div class="review_card">
                <div class="review_profile">
                    <img src="image/review_7.png">
                </div>

                <div class="review_text">
                    <h2 class="name">Nuwani R.</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        "Food’s so good! Portions are decent and prices are chill. One time delivery guy was a bit late, but food still warm so all good 😅"
                    </p>
                </div>
            </div>

            <div class="review_card">
                <div class="review_profile">
                    <img src="image/review_8.png">
                </div>

                <div class="review_text">
                    <h2 class="name">Tharindu Jayasena</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        "Tasty food, good pricing, and very helpful delivery staff. I just wish the app had better filters to sort by spice level or meal type. Other than that, excellent service!"
                    </p>
                </div>
            </div>

            <div class="review_card">
                <div class="review_profile">
                    <img src="image/review_9.png">
                </div>

                <div class="review_text">
                    <h2 class="name">Harsha D.</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        "Tried it randomly and now I’m hooked. Fast, tasty, and no drama. Love how I can just tap and get food without calling anyone."
                    </p>
                </div>
            </div>

            <div class="review_card">
                <div class="review_profile">
                    <img src="image/review_10.png">
                </div>

                <div class="review_text">
                    <h2 class="name">Shenali T.</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        "Honestly? Way better than other sites I’ve tried. Ordered dinner with my friends and everyone was super happy. 10/10 would eat again 😂🍔"
                    </p>
                </div>
            </div>

        </div>
    </div>
</section> 

<?php include 'includes/footer.php'; ?>