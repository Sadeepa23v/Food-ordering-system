<?php include 'includes/header.php'; ?>

<!-- Main container for the Menu section -->
<div class="menu" id="Menu">
    <h1>Food <span>Varieties</span></h1>
    <br>
    
        <!-- Wrapper for the main content -->
        <div class="main-content-wrapper">  
            
            <!-- Category carousel to filter menu items -->
            <div class="categories-carousel">
            <button class="carousel-btn left"><i class="fa fa-chevron-left"></i></button>
            
            <!-- Carousel track containing food categories -->
            <div class="carousel-track">
                <div class="carousel-item active" data-category="all">
                    <img src="image/cat-all.png" alt="All">
                    <span>All</span>
                </div>
                <div class="carousel-item" data-category="hotpicks">
                    <img src="image/cat-hotpicks.png" alt="Hot Picks">
                    <span>Hot Picks</span>
                </div>
                <div class="carousel-item" data-category="fastfood">
                    <img src="image/cat-fastfood.png" alt="Fast Food">
                    <span>Fast Food</span>
                </div>
                <div class="carousel-item" data-category="pizza">
                    <img src="image/cat-pizza.png" alt="Pizza">
                    <span>Pizza</span>
                </div>
                <div class="carousel-item" data-category="maindishes">
                    <img src="image/cat-maindishes.png" alt="Main Dishes">
                    <span>Main Dishes</span>
                </div>
                <div class="carousel-item" data-category="salads">
                    <img src="image/cat-salads.png" alt="Salads">
                    <span>Salads</span>
                </div>
                <div class="carousel-item" data-category="desserts">
                    <img src="image/cat-desserts.png" alt="Desserts">
                    <span>Desserts</span>
                </div>
                <div class="carousel-item" data-category="beverages">
                    <img src="image/cat-beverages.png" alt="Beverages">
                    <span>Beverages</span>
                </div>                
            </div>

            <button class="carousel-btn right"><i class="fa fa-chevron-right"></i></button>
            </div>        

        <!--Menu-->
        <div class="menu_box">        

        <!-- Category: Hot Picks -->
        <div data-category="hotpicks"><h2>Hot Picks</h2>
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-hot-spicy-chicken-wings.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Spicy Chicken Wings</h5>
                    <p>Crispy wings tossed in a fiery buffalo sauce.</p>
                    <h6>$7.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-hot-chilli-cheese-fries.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Chilli Cheese Fries</h5>
                    <p>Golden fries topped with spicy beef and cheddar.</p>
                    <h6>$5.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-hot-peri-peri-chicken-skewers.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Peri-Peri Chicken Skewers</h5>
                    <p>Grilled skewers marinated in tangy peri-peri sauce.</p>
                    <h6>$8.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-hot-bbq-pulled-pork-sliders.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>BBQ Pulled Pork Sliders</h5>
                    <p>Mini buns filled with smoky pulled pork.</p>
                    <h6>$6.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-hot-hot-garlic-prawns.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Hot Garlic Prawns</h5>
                    <p>Tiger prawns sautéed in chili garlic sauce.</p>
                    <h6>$9.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-hot-loaded-nachos.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Loaded Nachos</h5>
                    <p>Nachos with jalapeños, cheese, and beef.</p>
                    <h6>$6.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
            <div class="menu_image">
                <img src="image/cat-hot-sriracha-chicken-wrap.jpg">
            </div>
            <div class="small_card">
                <i class="fa-solid fa-heart"></i>
            </div>
            <div class="menu_info">
                <h5>Sriracha Chicken Wrap</h5>
                <p>Tortilla wrap with grilled chicken and sriracha mayo.</p>
                <h6>$7.49</h6>
                <div class="menu_icon">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star-half-stroke"></i>
                </div>
                <a href="auth/Login.php" class="menu_btn">Order Now</a>
            </div>
            </div>

            <div class="menu_card">
            <div class="menu_image">
                <img src="image/cat-hot-fiery-veggie-tacos.jpg">
            </div>
            <div class="small_card">
                <i class="fa-solid fa-heart"></i>
            </div>
            <div class="menu_info">
                <h5>Fiery Veggie Tacos</h5>
                <p>Spicy bean and vegetable tacos.</p>
                <h6>$5.99</h6>
                <div class="menu_icon">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star-half-stroke"></i>
                </div>
                <a href="auth/Login.php" class="menu_btn">Order Now</a>
            </div>
            </div>

            <div class="menu_card">
            <div class="menu_image">
                <img src="image/cat-hot-cajun-fried-chicken.jpg">
            </div>
            <div class="small_card">
                <i class="fa-solid fa-heart"></i>
            </div>
            <div class="menu_info">
                <h5>Cajun Fried Chicken</h5>
                <p>Southern-style chicken with Cajun spice.</p>
                <h6>$8.49</h6>
                <div class="menu_icon">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star-half-stroke"></i>
                </div>
                <a href="auth/Login.php" class="menu_btn">Order Now</a>
            </div>
            </div>

            <div class="menu_card">
            <div class="menu_image">
                <img src="image/cat-hot-spicy-mutton-chops.jpg">
            </div>
            <div class="small_card">
                <i class="fa-solid fa-heart"></i>
            </div>
            <div class="menu_info">
                <h5>Spicy Mutton Chops</h5>
                <p>Tender mutton cooked in hot masala.</p>
                <h6>$10.99</h6>
                <div class="menu_icon">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star-half-stroke"></i>
                </div>
                <a href="auth/Login.php" class="menu_btn">Order Now</a>            
            </div> 
            </div>
        </div>

        <!-- Category: Fast Food -->
        <div data-category="fastfood"><h2>Fast Food</h2>
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-fast-cheeseburger.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Cheeseburger</h5>
                    <p>Classic beef burger with melted cheese.</p>
                    <h6>$4.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-fast-chicken-sandwich.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Chicken Sandwich</h5>
                    <p>Crispy chicken fillet on a toasted bun.</p>
                    <h6>$5.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>            
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-fast-veggie-wrap.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Veggie Wrap</h5>
                    <p>Fresh veggies wrapped with hummus.</p>
                    <h6>$4.29</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-fast-french-fries.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>French Fries</h5>
                    <p>Golden and crispy potato fries.</p>
                    <h6>$2.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-fast-onion-rings.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Onion Rings</h5>
                    <p>Crunchy deep-fried onion rings.</p>
                    <h6>$2.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-fast-chicken-nuggets.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Chicken Nuggets</h5>
                    <p>Juicy chicken bites, perfect for dipping.</p>
                    <h6>$3.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-fast-fish-fillet-burger.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Fish Fillet Burger</h5>
                    <p>Breaded fish patty with tartar sauce.</p>
                    <h6>$5.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-fast-chicken-popcorn.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Chicken Popcorn</h5>
                    <p>Bite-sized crispy chicken pieces.</p>
                    <h6>$4.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-fast-mozzarella-sticks.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Mozzarella Sticks</h5>
                    <p>Melted mozzarella wrapped in a crispy shell.</p>
                    <h6>$4.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-fast-hotdog-classic.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Hot Dog Classic</h5>
                    <p>Grilled sausage in a soft bun with mustard.</p>
                    <h6>$3.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>
        </div> 

        <!-- Category: Pizza -->
        <div data-category="pizza"><h2>Pizza</h2>
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-pizza-margherita.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Margherita</h5>
                    <p>Classic cheese and tomato pizza.</p>
                    <h6>$7.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-pizza-pepperoni.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Pepperoni</h5>
                    <p>Loaded with spicy pepperoni slices.</p>
                    <h6>$8.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-pizza-bbq-chicken.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>BBQ Chicken</h5>
                    <p>Grilled chicken with BBQ sauce.</p>
                    <h6>$9.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-pizza-veggie-deluxe.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Veggie Deluxe</h5>
                    <p>Bell peppers, olives, onions & mushrooms.</p>                    
                    <h6>$8.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-pizza-meat-lovers.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Meat Lovers</h5>
                    <p>A mix of beef, chicken, ham, and sausage.</p>
                    <h6>$10.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-pizza-four-cheese.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Four Cheese</h5>
                    <p>Mozzarella, cheddar, feta, and parmesan.</p>
                    <h6>$9.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-pizza-hawaiian.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Hawaiian</h5>
                    <p>Pineapple and ham combo.</p>
                    <h6>$8.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-pizza-spicy-paneer.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Spicy Paneer</h5>
                    <p>Indian twist with spiced paneer cubes.</p>
                    <h6>$8.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-pizza-chicken-alfredo.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Chicken Alfredo</h5>
                    <p>Creamy white sauce with grilled chicken.</p>
                    <h6>$9.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-pizza-mushroom-feast.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Mushroom Feast</h5>
                    <p>Sauteed mushrooms with herbs and cheese.</p>
                    <h6>$8.29</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>
        </div>

        <!-- Category: Main Dishes -->
        <div data-category="maindishes"><h2>Main Dishes</h2>
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-main-grilled-chicken-platter.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Grilled Chicken Platter</h5>
                    <p>Chicken breast with rice and veggies.</p>
                    <h6>$12.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-main-beef-steak.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Beef Steak</h5>
                    <p>Grilled steak with peppercorn sauce.</p>
                    <h6>$15.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-main-chicken-biriyani.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Chicken Biriyani</h5>
                    <p>Spiced rice with marinated chicken.</p>
                    <h6>$10.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-main-vegetable-curry.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Vegetable Curry</h5>
                    <p>Mixed vegetables in coconut curry.</p>
                    <h6>$8.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-main-butter-chicken.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Butter Chicken</h5>
                    <p>Creamy tomato-based chicken curry.</p>
                    <h6>$11.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-main-grilled-salmon.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Grilled Salmon</h5>
                    <p>Served with lemon herb sauce and salad.</p>
                    <h6>$14.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-main-roast-chicken-dinner.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Roast Chicken Dinner</h5>
                    <p>Half-roast chicken with potatoes and gravy.</p>
                    <h6>$13.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-main-spaghetti.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Spaghetti Bolognese</h5>
                    <p>Pasta in rich meat sauce.</p>
                    <h6>$9.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-main-tofu.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Tofu Stir Fry</h5>
                    <p>Tofu and veggies tossed in soy sauce.</p>
                    <h6>$9.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-main-lamb-curry.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Lamb Curry</h5>
                    <p>Tender lamb cooked in aromatic spices.</p>
                    <h6>$12.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>
        </div>

        <!-- Category: Salads -->
        <div data-category="salads"><h2>Salads</h2>
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-salad-caesar.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Caesar Salad</h5>
                    <p>Romaine lettuce, parmesan & croutons.</p>
                    <h6>$6.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-salad-greek.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Greek Salad</h5>
                    <p>Feta, olives, cucumber, and tomatoes.</p>
                    <h6>$7.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-salad-chicken-garden.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Chicken Garden Salad</h5>
                    <p>Grilled chicken with fresh greens.</p>
                    <h6>$8.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-salad-tuna.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Tuna Salad</h5>
                    <p>Tuna with beans, lettuce, and vinaigrette.</p>
                    <h6>$7.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-salad-caprese.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Caprese Salad</h5>
                    <p>Tomato, mozzarella, basil, and olive oil.</p>
                    <h6>$6.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-salad-egg.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Egg Salad</h5>
                    <p>Creamy egg mix with herbs.</p>
                    <h6>$5.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-salad-avocado.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Avocado Salad</h5>
                    <p>Avocado, cherry tomatoes & lime dressing.</p>
                    <h6>$7.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-salad-quinoa.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Quinoa Salad</h5>
                    <p>Quinoa with vegetables and lemon.</p>
                    <h6>$8.29</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-salad-coleslaw.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Coleslaw Salad</h5>
                    <p>Crunchy cabbage in creamy dressing.</p>
                    <h6>$4.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-salad-shrimp.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Shrimp Salad</h5>
                    <p>Chilled shrimp with greens and citrus.</p>
                    <h6>$9.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>
        </div>

        <!-- Category: Desserts -->
        <div data-category="desserts"><h2>Desserts</h2>
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-des-choc-lava.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Chocolate Lava Cake</h5>
                    <p>Warm cake with gooey chocolate center.</p>
                    <h6>$4.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-des-cheesecake.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Cheesecake</h5>
                    <p>Creamy slice with a buttery crust.</p>
                    <h6>$4.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-des-brownie-sundae.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Brownie Sundae</h5>
                    <p>Brownie topped with vanilla ice cream.</p>
                    <h6>$5.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-des-fruitsalad.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Fruit Salad</h5>
                    <p>Fresh seasonal fruits with honey.</p>
                    <h6>$3.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-des-icecream.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Ice Cream Triple Scoop</h5>
                    <p>Choose 3 flavors from our ice cream bar.</p>
                    <h6>$4.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-des-mango-mousse.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Mango Mousse</h5>
                    <p>Light and fluffy mango-flavored mousse.</p>
                    <h6>$4.29</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-des-tiramisu.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Tiramisu</h5>
                    <p>Italian layered dessert with coffee flavor.</p>
                    <h6>$5.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-des-gulab.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Gulab Jamun</h5>
                    <p>Indian sweet dumplings soaked in syrup.</p>
                    <h6>$3.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-des-waffle.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Waffle with Syrup</h5>
                    <p>Freshly baked waffle with maple syrup.</p>
                    <h6>$4.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-des-carrot-cake.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Carrot Cake</h5>
                    <p>Moist cake topped with cream cheese frosting.</p>
                    <h6>$4.79</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>
        </div>
        
        <!-- Category: Beverages -->
        <div data-category="beverages"><h2>Beverages</h2>
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-bev-cocacola.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Coca-Cola (Can)</h5>
                    <p>Classic soft drink.</p>
                    <h6>$1.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-bev-orange-juice.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Fresh Orange Juice</h5>
                    <p>Freshly squeezed and vitamin-rich.</p>
                    <h6>$3.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-bev-iced-tea.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Iced Tea</h5>
                    <p>Cold black tea with lemon.</p>
                    <h6>$2.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-bev-mango-smoothie.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Mango Smoothie</h5>
                    <p>Creamy mango blend with yogurt.</p>
                    <h6>$4.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-bev-cold-coffee.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Cold Coffee</h5>
                    <p>Chilled coffee with milk and sugar.</p>
                    <h6>$3.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-bev-lemon-mint-cooler.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Lemon Mint Cooler</h5>
                    <p>Zesty lemon and mint beverage.</p>
                    <h6>$3.79</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 
            
            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-bev-strawberry-milkshake.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Milkshake (Strawberry)</h5>
                    <p>Rich and thick strawberry shake.</p>
                    <h6>$4.29</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-bev-green-tea.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Green Tea</h5>
                    <p>Light and antioxidant-rich.</p>
                    <h6>$2.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-bev-hot-chocolate.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Hot Chocolate</h5>
                    <p>Creamy and warm cocoa drink.</p>
                    <h6>$3.99</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div> 

            <div class="menu_card">
                <div class="menu_image">
                    <img src="image/cat-bev-mineral-water.jpg">
                </div>
                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="menu_info">
                    <h5>Mineral Water (Bottle)</h5>
                    <p>Pure and refreshing bottled water.</p>
                    <h6>$1.49</h6>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="auth/Login.php" class="menu_btn">Order Now</a>
                </div>
            </div>          
        </div>
        </div>

<?php include 'includes/footer.php'; ?>