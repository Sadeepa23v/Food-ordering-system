<?php
    //variable to use database
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'food-ordering-system';

    //function with arguments to connect to database
    $conn = mysqli_connect($host, $username, $password, $database);

    if(!$conn)
    {
        //die to terminate (stop) code
        die("Connection Failed: " . mysqli_connect_error());
    } 
?>