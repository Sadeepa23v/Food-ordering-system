<?php
include '../includes/session_check.php';
checkRole('admin');
include '../configure.php';
include '../includes/admin_header.php';



if (!isset($conn) || !$conn) {
    echo "<div class='error-message'>Database connection failed.</div>";
    include '../includes/footer.php';
    exit();
}

if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
    header("Location: ../admin/manage_food_items.php");
    exit();
}

$id = intval($_GET['id']);

// Fetch existing data
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    $stmt = $conn->prepare("SELECT Name, Description, Price, Image, Category, Rating FROM food_items WHERE Item_ID=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($name, $description, $price, $image, $category, $rating);
    if (!$stmt->fetch()) {
        echo "<div class='error-message'>Item not found.</div>";
        include '../includes/footer.php';
        exit();
    }
    $stmt->close();
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $category = $_POST['category'];
    $rating = floatval($_POST['rating']);
    $imagePath = $image; // default to existing

    // Image upload if provided
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = "../uploads/";
        $imageName = basename($_FILES['image']['name']);
        $targetFile = $uploadDir . $imageName;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($imageFileType, $allowedTypes)) {
            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                $imagePath = $targetFile;
            } else {
                $error = "Image upload failed.";
            }
        } else {
            $error = "Invalid image format. Only JPG, JPEG, PNG, GIF allowed.";
        }
    }

    if (empty($error) && $name && $price > 0 && $category) {
        $stmt = $conn->prepare("UPDATE food_items SET Name=?, Description=?, Price=?, Image=?, Category=?, Rating=? WHERE Item_ID=?");
        $stmt->bind_param("ssdssdi", $name, $description, $price, $imagePath, $category, $rating, $id);

        if ($stmt->execute()) {
            $stmt->close();
            $_SESSION['success'] = "Food item updated successfully!";
            header("Location: ../admin/manage_food_items.php");
            exit();
        } else {
            $error = "Error updating item: " . $stmt->error;
            $stmt->close();
        }
    } else {
        if (empty($error)) {
            $error = "Please fill all fields correctly.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Food Item - Admin Dashboard</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>
<div class="admin-form-container">
    <h2>Edit Food Item</h2>
    <?php if (!empty($error)): ?>
        <div class="error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form class="admin-form" action="update_food.php?id=<?= $id ?>" method="POST" enctype="multipart/form-data">
        <label>
            Name:
            <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>
        </label>
        <label>
            Description:
            <textarea name="description" rows="3"><?= htmlspecialchars($description) ?></textarea>
        </label>
        <label>
            Price:
            <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($price) ?>" required>
        </label>
        <label>
            Category:
            <select name="category" required>
                <?php
                $categories = ['Hot Picks', 'Fast Food', 'Pizza', 'Main Dishes', 'Salads', 'Desserts', 'Beverages'];
                foreach ($categories as $cat) {
                    $selected = ($category === $cat) ? 'selected' : '';
                    echo "<option value=\"$cat\" $selected>$cat</option>";
                }
                ?>
            </select>
        </label>
        <br>

        <label>
            Rating:
            <input type="number" step="0.1" max="5" min="0" name="rating" value="<?= htmlspecialchars($rating) ?>" required>
        </label>
        <label>
            Image: <br>
            <?php if (!empty($image)): ?>
                <img src="<?= $image ?>" alt="Current Image" style="max-width: 120px; display:block; margin: 8px 0;">
            <?php endif; ?>
            <input type="file" name="image" accept="image/*">
        </label>
        <input type="submit" value="Update Item">
    </form>
</div>
</body>
</html>

<?php include '../includes/footer.php'; ?>
