<?php
include '../includes/session_check.php';
checkRole('admin');
include '../configure.php';
include '../includes/admin_header.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $category = $_POST['category'];
    $rating = isset($_POST['rating']) ? floatval($_POST['rating']) : 0.0;

    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $imageName = basename($_FILES['image']['name']);
        $targetDir = "../uploads/";
        $targetFile = $targetDir . $imageName;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $imagePath = "uploads/" . $imageName;
        } else {
            $error = "Image upload failed.";
        }
    } else {
        $imagePath = "";
    }

    if (!$error && $name && $price > 0 && $category) {
        $stmt = $conn->prepare("INSERT INTO food_items (Name, Description, Price, Image, Category, Rating) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdssd", $name, $description, $price, $imagePath, $category, $rating);
        if ($stmt->execute()) {
            $success = "Food item added successfully.";
            $stmt->close();
        } else {
            $error = "Database Error: " . $stmt->error;
            $stmt->close();
        }
    } elseif (!$error) {
        $error = "Please fill all required fields correctly.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Food Item</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<body>
<div class="admin-form-container">
    <h2>Add New Food Item</h2>

    <?php if ($error): ?>
        <div class="error-message"><?= htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success-message"><?= htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <form class="admin-form" action="create_food.php" method="POST" enctype="multipart/form-data">
        <label>
            Name:
            <input type="text" name="name" required>
        </label>

        <label>
            Description:
            <textarea name="description" rows="3" required></textarea>
        </label>

        <label>
            Price:
            <input type="number" name="price" step="0.01" required>
        </label>

        <label>
            Image:
            <input type="file" name="image" accept="image/*">
        </label>
        <br> 

        <label>
            Category:
            <select name="category" required>
                <option value="" disabled selected>Select Category</option>
                <option value="Hot Picks">Hot Picks</option>
                <option value="Fast Food">Fast Food</option>
                <option value="Pizza">Pizza</option>
                <option value="Main Dishes">Main Dishes</option>
                <option value="Salads">Salads</option>
                <option value="Desserts">Desserts</option>
                <option value="Beverages">Beverages</option>
            </select>
        </label>
        <br>

        <label>
            Rating (optional):
            <input type="number" name="rating" step="0.1" min="0" max="5" placeholder="0.0 to 5.0">
        </label>

        <input type="submit" value="Add Item">
    </form>
</div>

<?php include '../includes/footer.php'; ?>

</body>
</html>
