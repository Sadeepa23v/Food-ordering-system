<?php
session_start();
include '../includes/session_check.php';
checkRole('admin');
include '../configure.php';
include '../includes/admin_header.php';

if (!isset($conn) || !$conn) {
    echo "<div class='error-message'>Database connection failed.</div>";
    include '../includes/footer.php';
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: ../admin/manage_food_items.php");
    exit();
}

$itemId = intval($_GET['id']);

if ($itemId <= 0) {
    header("Location: ../admin/manage_food_items.php");
    exit();
}

// Use the correct column name: Item_ID
$stmt = $conn->prepare("DELETE FROM food_items WHERE Item_ID = ?");

if ($stmt) {
    $stmt->bind_param("i", $itemId);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Food item deleted successfully.";
        $stmt->close();
        header("Location: ../admin/manage_food_items.php");
        exit();
    } else {
        echo "<div class='error-message'>Error deleting item: " . htmlspecialchars($stmt->error) . "</div>";
        $stmt->close();
    }
} else {
    echo "<div class='error-message'>Error preparing delete statement: " . htmlspecialchars($conn->error) . "</div>";
}

include '../includes/footer.php';
?>
